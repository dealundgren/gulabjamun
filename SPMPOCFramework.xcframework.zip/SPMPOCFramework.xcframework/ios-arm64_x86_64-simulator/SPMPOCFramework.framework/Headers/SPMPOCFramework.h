//
//  SPMPOCFramework.h
//  SPMPOCFramework
//
//  Created by David Lundgren on 5/5/23.
//

#import <Foundation/Foundation.h>

//! Project version number for SPMPOCFramework.
FOUNDATION_EXPORT double SPMPOCFrameworkVersionNumber;

//! Project version string for SPMPOCFramework.
FOUNDATION_EXPORT const unsigned char SPMPOCFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SPMPOCFramework/PublicHeader.h>


